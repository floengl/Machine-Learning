from utils import load_dataset

X,y=load_dataset()
print(X)